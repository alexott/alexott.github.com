/*  -*- C++ -*-
    File: schemeargs.h

    Created: 22 Oct 2001
    $Id: schemeargs.h,v 1.3 2002/08/30 07:43:16 ott Exp $
 */

#ifndef _SCHEMEARGS_H
#define _SCHEMEARGS_H 1

#define CHECK_ARG_TYPE_INT(N,FUNC) \
     if (!SCHEME_INTP (argv[(N)])) \
       scheme_wrong_type ((FUNC), "integer", (N), argc, argv)

#define CHECK_ARG_TYPE_STRING(N,FUNC) \
     if (!SCHEME_STRINGP (argv[(N)])) \
       scheme_wrong_type ((FUNC), "string", (N), argc, argv)

#define CHECK_ARG_TYPE_VECTOR(N,FUNC) \
     if (!SCHEME_VECTORP (argv[(N)])) \
       scheme_wrong_type ((FUNC), "vector", (N), argc, argv)

#define CHECK_ARG_TYPE_PROC(N,FUNC) \
     if (!SCHEME_PROCP (argv[(N)])) \
       scheme_wrong_type ((FUNC), "procedure", (N), argc, argv)

#endif /* _SCHEMEARGS_H */

