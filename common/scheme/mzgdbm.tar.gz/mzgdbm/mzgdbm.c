/** -*- C -*-
 * @file   mzgdbm.c
 * @author Alex Ott <ottalex@narod.ru>
 * @date   24 ��� 2002
 * Version: $Id: mzgdbm.c,v 1.6 2002/12/16 14:40:22 ott Exp $
 * 
 * @brief This is interface to GNU dbm for MzScheme
 *
 */

#include <escheme.h>
#include <string.h>
#include <schemeargs.h>

#include <gdbm.h>
#include <sys/stat.h>

/**
 * type for structure GDBM_FILE
 * 
 */
typedef struct tagGBDMFILE {
	Scheme_Type type;							/**< Scheme type */
	GDBM_FILE dbf;								/**< pointer rtto gdbm file structure */
	datum key;										/**< saved key for some functions */
} GDBMFILE, *LPGDBMFILE;

static Scheme_Type scheme_gdbm_file_type;

#define SCHEME_GDBM_FILE(OBJ) \
     (SAME_TYPE (SCHEME_TYPE ((LPGDBMFILE)(OBJ)), \
                 scheme_gdbm_file_type))

#define CHECK_ARG_TYPE_GDBM_FILE(N,FUNC) \
     if (!SCHEME_GDBM_FILE (argv[(N)])) \
       scheme_wrong_type ((FUNC), "gdbm:file", (N), argc, argv)

/** 
 * Check is the argument gdbm:file type
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return true if argv[0] is gdbm:file
 */
Scheme_Object* scheme_gdbm_filep(int argc, Scheme_Object *argv[]) {
   return SCHEME_GDBM_FILE(argv[0]) ? scheme_true : scheme_false;
}

/** 
 * Return value of gdbm_errno variable
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return value of gdbm_errno variable
 */
Scheme_Object *scheme_gdbm_get_error(int argc, Scheme_Object *argv[]) {
   return scheme_make_integer(gdbm_errno);
}

/** 
 * 
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return string, describing gdbm error
 */
Scheme_Object *scheme_gdbm_strerror(int argc, Scheme_Object *argv[]) {
   if(argc == 0) {
      return scheme_make_string(gdbm_strerror(gdbm_errno));
   } else {
      CHECK_ARG_TYPE_INT(0, "gdbm:strerror");
      return scheme_make_string(gdbm_strerror( SCHEME_INT_VAL(argv[0])));
   }
}

/** 
 * Open gdbm file
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_open(int argc, Scheme_Object *argv[]) {
   GDBM_FILE dbf;
   Scheme_Object *gdbmfile;
   int flags=GDBM_READER;
   int mode=S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH;
  
   CHECK_ARG_TYPE_STRING(0, "gdbm:open");
   if (argc > 1) {
      CHECK_ARG_TYPE_INT(1, "gdbm:open");
      flags=SCHEME_INT_VAL(argv[1]);
      if (argc > 2) {
         CHECK_ARG_TYPE_INT(2, "gdbm:open");
         mode=SCHEME_INT_VAL(argv[2]);
      }
   }
  
   dbf=gdbm_open(SCHEME_STR_VAL(argv[0]), 0, flags, mode, NULL);
   if (dbf == NULL) {
      scheme_signal_error("Error while open database: %s", gdbm_strerror(gdbm_errno));
   }
   gdbmfile=(Scheme_Object *)scheme_malloc_atomic(sizeof(GDBMFILE));
   gdbmfile->type=scheme_gdbm_file_type;
   ((LPGDBMFILE)gdbmfile)->dbf=dbf;
   ((LPGDBMFILE)gdbmfile)->key.dptr=NULL;
   ((LPGDBMFILE)gdbmfile)->key.dsize=0;
/*   ((LPGDBMFILE)gdbmfile)->str=scheme_make_string(""); */

   return gdbmfile;
}

/** 
 * Close opened database
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_close(int argc, Scheme_Object *argv[]) {
   LPGDBMFILE pDbf;
  
   CHECK_ARG_TYPE_GDBM_FILE(0, "gdbm:close");
   pDbf=(LPGDBMFILE)argv[0];
   if ( pDbf->key.dptr != NULL)
      free(pDbf->key.dptr);
	 pDbf->key.dptr=NULL;
  
   SCHEME_ASSERT(pDbf->dbf, "Error in 'gdbm:close': database is already closed");
	 pDbf->dbf=NULL;
   return scheme_void;
}

#define MAX_INT_LEN 25
/** 
 * Store data in database
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_store(int argc, Scheme_Object *argv[]) {
   LPGDBMFILE pDbf;
   int ret, mode=GDBM_INSERT, i;
   datum data[2];
   char buf[2][MAX_INT_LEN+1];
   Scheme_Object *so[2];
   
   CHECK_ARG_TYPE_GDBM_FILE(0, "gdbm:store");
   pDbf=(LPGDBMFILE)argv[0];

   if (SCHEME_PAIRP(argv[1])) {
      so[0]=scheme_car(argv[1]);
      so[1]=scheme_cdr(argv[1]);
      if (SCHEME_PAIRP(so[1]))
         so[1]=scheme_car(so[1]);
      if (argc >2 ) {
         CHECK_ARG_TYPE_INT(2, "gdbm:store");
         mode=SCHEME_INT_VAL(argv[2]);
      }
   } else {
      so[0]=argv[1];
      so[1]=argv[2];
      if (argc >3 ) {
         CHECK_ARG_TYPE_INT(3, "gdbm:store");
         mode=SCHEME_INT_VAL(argv[3]);
      }
   }
   
   for( i=0; i<=1; i++) {
      if (SCHEME_INTP(so[i])) {
         snprintf(buf[i], MAX_INT_LEN, "%ld",SCHEME_INT_VAL(so[i]));
         data[i].dptr=buf[i];
				 data[i].dsize=strlen(data[i].dptr);
      } else if (SCHEME_FLTP(so[i])) {
         snprintf(buf[i], MAX_INT_LEN, "%f",SCHEME_FLT_VAL(so[i]));
         data[i].dptr=buf[i];
				 data[i].dsize=strlen(data[i].dptr);
      } else if (SCHEME_STRINGP(so[i])) {
         data[i].dptr=SCHEME_STR_VAL(so[i]);
				 data[i].dsize=SCHEME_STRLEN_VAL(so[i]);
      } else {
         scheme_signal_error("Error in gdbm:store while storing data: unsupported data type");
      }
   }
  
   ret=gdbm_store(pDbf->dbf, data[0], data[1], mode);
   if ( ret == 1) {
      scheme_signal_error("Error in gdbm:store while storing data: key already exists or unknown mode");
   } else if (ret == -1 ) {
      scheme_signal_error("Error in gdbm:store while storing data: database open for read");
   }
  
   return scheme_void;
}

/** 
 * Fetch data by given key
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_fetch(int argc, Scheme_Object *argv[]) {
   LPGDBMFILE pDbf;
   datum key, content;
   char buf[MAX_INT_LEN+1];
   Scheme_Object *res;

   CHECK_ARG_TYPE_GDBM_FILE(0, "gdbm:fetch");
   pDbf=(LPGDBMFILE)argv[0];

   if (SCHEME_INTP(argv[1])) {
      snprintf(buf, MAX_INT_LEN, "%ld",SCHEME_INT_VAL(argv[1]));
      key.dptr=buf;
			key.dsize=strlen(key.dptr);
   } else if (SCHEME_FLTP(argv[1])) {
      snprintf(buf, MAX_INT_LEN, "%f",SCHEME_FLT_VAL(argv[1]));
      key.dptr=buf;
			key.dsize=strlen(key.dptr);
   } else if (SCHEME_STRINGP(argv[1])) {
      key.dptr=SCHEME_STR_VAL(argv[1]);
			key.dsize=SCHEME_STRLEN_VAL(argv[1]);
   } else {
      scheme_signal_error("Error in gdbm:fetch while storing data: unsupported data type");
   }
   content=gdbm_fetch(pDbf->dbf, key);
   if (content.dptr !=NULL ) {
      res=scheme_make_sized_string(content.dptr,content.dsize,1);
      free(content.dptr);
      return res;
   } else
      return scheme_false;
}

/** 
 * Delete  data from db with given key
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_delete(int argc, Scheme_Object *argv[]) {
   LPGDBMFILE pDbf;
   datum key;
   char buf[MAX_INT_LEN+1];

   CHECK_ARG_TYPE_GDBM_FILE(0, "gdbm:delete");
   pDbf=(LPGDBMFILE)argv[0];

   if (SCHEME_INTP(argv[1])) {
      snprintf(buf, MAX_INT_LEN, "%ld",SCHEME_INT_VAL(argv[1]));
      key.dptr=buf;
			key.dsize=strlen(key.dptr);
   } else if (SCHEME_FLTP(argv[1])) {
      snprintf(buf, MAX_INT_LEN, "%f",SCHEME_FLT_VAL(argv[1]));
      key.dptr=buf;
			key.dsize=strlen(key.dptr);
   } else if (SCHEME_STRINGP(argv[1])) {
      key.dptr=SCHEME_STR_VAL(argv[1]);
			key.dsize=SCHEME_STRLEN_VAL(argv[1]);
   } else {
      scheme_signal_error("Error in gdbm:delete while fetching data: unsupported data type");
   }
   if ( gdbm_delete(pDbf->dbf, key) != 0 ) {
      scheme_signal_error("Error in gdbm:delete: key is not presented");
   }
	 return scheme_void;
}

/** 
 * Return first pair from db
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_firstpair(int argc, Scheme_Object *argv[]) {
   LPGDBMFILE pDbf;
   Scheme_Object *data, *key;
   datum tdata;
   
   CHECK_ARG_TYPE_GDBM_FILE(0, "gdbm:first-pair");
   pDbf=(LPGDBMFILE)argv[0];

   if (pDbf->key.dptr != NULL )
      free(pDbf->key.dptr);

   pDbf->key=gdbm_firstkey(pDbf->dbf);
  
   if (pDbf->key.dptr == NULL )
      return scheme_null;

   tdata=gdbm_fetch(pDbf->dbf, pDbf->key);
   key=scheme_make_sized_string(pDbf->key.dptr,pDbf->key.dsize,1);
   data=scheme_make_sized_string(tdata.dptr,tdata.dsize,1);
   free(tdata.dptr);
   
   return scheme_make_pair(key,data);
}

/** 
 * Return next pair from db
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_nextpair(int argc, Scheme_Object *argv[]) {
   LPGDBMFILE pDbf;
   datum tdata;
   Scheme_Object *data, *key;
   
   CHECK_ARG_TYPE_GDBM_FILE(0, "gdbm:next-pair");
   pDbf=(LPGDBMFILE)argv[0];

   if (pDbf->key.dptr == NULL )
      return scheme_null;
   
   tdata=pDbf->key;
   pDbf->key=gdbm_nextkey(pDbf->dbf,tdata);
  
   free(tdata.dptr);
   if (pDbf->key.dptr == NULL )
      return scheme_null;

   tdata=gdbm_fetch(pDbf->dbf, pDbf->key);
   key=scheme_make_sized_string(pDbf->key.dptr,pDbf->key.dsize,1);
   data=scheme_make_sized_string(tdata.dptr,tdata.dsize,1);
   free(tdata.dptr);

	 return scheme_make_pair(key,data);
}

/** 
 * Return first key from db
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_firstkey(int argc, Scheme_Object *argv[]) {
   LPGDBMFILE pDbf;
   Scheme_Object *key;
   
   CHECK_ARG_TYPE_GDBM_FILE(0, "gdbm:first-key");
   pDbf=(LPGDBMFILE)argv[0];

   if (pDbf->key.dptr != NULL )
      free(pDbf->key.dptr);

   pDbf->key=gdbm_firstkey(pDbf->dbf);
  
   if (pDbf->key.dptr == NULL )
      return scheme_false;

   key=scheme_make_sized_string(pDbf->key.dptr,pDbf->key.dsize,1);
   
   return key;
}

/** 
 * Return next key from db
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_nextkey(int argc, Scheme_Object *argv[]) {
   LPGDBMFILE pDbf;
   datum tdata;
   Scheme_Object *key;
   
   CHECK_ARG_TYPE_GDBM_FILE(0, "gdbm:next-key");
   pDbf=(LPGDBMFILE)argv[0];

   if (pDbf->key.dptr == NULL )
      return scheme_false;
   
   tdata=pDbf->key;
   pDbf->key=gdbm_nextkey(pDbf->dbf,tdata);
   free(tdata.dptr);

   if (pDbf->key.dptr == NULL )
      return scheme_false;

   key=scheme_make_sized_string(pDbf->key.dptr,pDbf->key.dsize,1);
   
   return key;
}

/** 
 * Reorganize db, clearing deleted data
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_reorganize(int argc, Scheme_Object *argv[]) {
   LPGDBMFILE pDbf;
   CHECK_ARG_TYPE_GDBM_FILE(0, "gdbm:reorganize");
   pDbf=(LPGDBMFILE)argv[0];

   if ( gdbm_reorganize(pDbf->dbf) != 0 ) {
      scheme_signal_error("Error in gdbm:reorganize");
   }
	 return scheme_void;
}

/** 
 * Sync database
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_sync(int argc, Scheme_Object *argv[]) {
   LPGDBMFILE pDbf;
   CHECK_ARG_TYPE_GDBM_FILE(0, "gdbm:sync");
   pDbf=(LPGDBMFILE)argv[0];

   gdbm_sync(pDbf->dbf);
  
   return scheme_void;
}

/** 
 * Check, is data for key exists?
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_exists(int argc, Scheme_Object *argv[]) {
   LPGDBMFILE pDbf;
   datum key;
   char buf[MAX_INT_LEN+1];

   CHECK_ARG_TYPE_GDBM_FILE(0, "gdbm:exists?");
   pDbf=(LPGDBMFILE)argv[0];

   if (SCHEME_INTP(argv[1])) {
      snprintf(buf, MAX_INT_LEN, "%ld",SCHEME_INT_VAL(argv[1]));
      key.dptr=buf;
			key.dsize=strlen(key.dptr);
   } else if (SCHEME_FLTP(argv[1])) {
      snprintf(buf, MAX_INT_LEN, "%f",SCHEME_FLT_VAL(argv[1]));
      key.dptr=buf;
			key.dsize=strlen(key.dptr);
   } else if (SCHEME_STRINGP(argv[1])) {
      key.dptr=SCHEME_STR_VAL(argv[1]);
			key.dsize=SCHEME_STRLEN_VAL(argv[1]);
   } else {
      scheme_signal_error("Error in gdbm:exists? while storing data: unsupported data type");
   }
   if ( gdbm_exists(pDbf->dbf, key) ) {
      return scheme_true;
   } else
      return scheme_false;
}

/** 
 * Set option for db
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_setopt(int argc, Scheme_Object *argv[]) {
   LPGDBMFILE pDbf;
   CHECK_ARG_TYPE_GDBM_FILE(0, "gdbm:set-option");
   pDbf=(LPGDBMFILE)argv[0];

   return scheme_void;
}

/** 
 * Return file descriptor for db file
 * 
 * @param argc number of arguments
 * @param argv arguments:
 * 
 * @return 
 */
Scheme_Object *scheme_gdbm_fdesc(int argc, Scheme_Object *argv[]) {
   LPGDBMFILE pDbf;
   CHECK_ARG_TYPE_GDBM_FILE(0, "gdbm:file-descriptor");
   pDbf=(LPGDBMFILE)argv[0];
   return scheme_make_integer(gdbm_fdesc(pDbf->dbf));
}


/** 
 * Initilize Scheme environment
 * 
 * @param env 
 * 
 * @return 
 */
Scheme_Object *scheme_initialize(Scheme_Env *env) {
/* type for GDBM_FILE */
   scheme_gdbm_file_type=scheme_make_type("<gdbm:file>");

/* Exported functions */
	 scheme_add_global("gdbm:open",
                     scheme_make_prim_w_arity(scheme_gdbm_open,
                                              "gdbm:open", 1, 3), env);
   scheme_add_global("gdbm:close",
                     scheme_make_prim_w_arity(scheme_gdbm_close,
                                              "gdbm:close", 1, 1), env);
   scheme_add_global("gdbm:file?",
                     scheme_make_prim_w_arity(scheme_gdbm_filep,
                                              "gdbm:file?", 1, 1), env);
   scheme_add_global("gdbm:store",
                     scheme_make_prim_w_arity(scheme_gdbm_store,
                                              "gdbm:store", 2, 4), env);
   scheme_add_global("gdbm:fetch",
                     scheme_make_prim_w_arity(scheme_gdbm_fetch,
                                              "gdbm:fetch", 2, 2), env);
   scheme_add_global("gdbm:exists?",
                     scheme_make_prim_w_arity(scheme_gdbm_exists,
                                              "gdbm:exists?", 2, 2), env);
   scheme_add_global("gdbm:delete",
                     scheme_make_prim_w_arity(scheme_gdbm_delete,
                                              "gdbm:delete", 2, 2), env);
   scheme_add_global("gdbm:reorganize",
                     scheme_make_prim_w_arity(scheme_gdbm_reorganize,
                                              "gdbm:reorganize", 1, 1), env);
   scheme_add_global("gdbm:sync",
                     scheme_make_prim_w_arity(scheme_gdbm_sync,
                                              "gdbm:sync", 1, 1), env);
   scheme_add_global("gdbm:get-error",
                     scheme_make_prim_w_arity(scheme_gdbm_get_error,
                                              "gdbm:get-error", 0, 0), env);
   scheme_add_global("gdbm:strerror",
                     scheme_make_prim_w_arity(scheme_gdbm_strerror,
                                              "gdbm:strerror", 0, 1), env);
   scheme_add_global("gdbm:set-option",
                     scheme_make_prim_w_arity(scheme_gdbm_setopt,
                                              "gdbm:set-option", 3, 3), env);
   scheme_add_global("gdbm:file-descriptor",
                     scheme_make_prim_w_arity(scheme_gdbm_fdesc,
                                              "gdbm:file-descriptor", 1, 1), env);
  scheme_add_global("gdbm:first-key",
                    scheme_make_prim_w_arity(scheme_gdbm_firstkey,
                                             "gdbm:first-key", 1, 1), env);
  scheme_add_global("gdbm:next-key",
                    scheme_make_prim_w_arity(scheme_gdbm_nextkey,
                                             "gdbm:next-key", 1, 1), env);
  scheme_add_global("gdbm:first-pair",
                    scheme_make_prim_w_arity(scheme_gdbm_firstpair,
                                             "gdbm:first-pair", 1, 1), env);
  scheme_add_global("gdbm:next-pair",
                    scheme_make_prim_w_arity(scheme_gdbm_nextpair,
                                             "gdbm:next-pair", 1, 1), env);

   /**
    * Constants for gdbm file open
    * 
    */
   scheme_add_global(":gdbm:reader", 
                     scheme_make_integer_value(GDBM_READER), env);
   scheme_add_global(":gdbm:writer", 
                     scheme_make_integer_value(GDBM_WRITER), env);
   scheme_add_global(":gdbm:write-create", 
                     scheme_make_integer_value(GDBM_WRCREAT), env);
   scheme_add_global(":gdbm:new-database", 
                     scheme_make_integer_value(GDBM_NEWDB), env);
   scheme_add_global(":gdbm:sync", 
                     scheme_make_integer_value(GDBM_SYNC), env);
   scheme_add_global(":gdbm:no-lock", 
                     scheme_make_integer_value(GDBM_NOLOCK), env);
   scheme_add_global(":gdbm:replace", 
                     scheme_make_integer_value(GDBM_REPLACE), env);
   scheme_add_global(":gdbm:insert", 
                     scheme_make_integer_value(GDBM_INSERT), env);
  
   return scheme_void;
}

Scheme_Object *scheme_reload(Scheme_Env *env) {
   // Nothing special for reload
   return scheme_void;
   //  return scheme_initialize(env);
}


/*
	c-basic-offset: 2
*/

