%%% File    : (>>FILE<<)
%%% Author  : Alex Ott <alexott@gmail.com>
%%% Created : (>>DATE<<) by Alex Ott
%%% Description : 
%%%

-module((>>FILE_NO_EXT<<)).
%% -export([]).
%% -import(,[])
%% -compile(export_all).

